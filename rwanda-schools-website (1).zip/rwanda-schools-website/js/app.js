// Rwanda Schools Directory - Main JavaScript File

class SchoolsDirectory {
    constructor() {
        this.schools = [];
        this.filteredSchools = [];
        this.currentPage = 1;
        this.schoolsPerPage = 12;
        this.init();
    }

    async init() {
        try {
            await this.loadSchoolsData();
            this.setupEventListeners();
            this.populateFilters();
            this.updateStatistics();
            this.displaySchools();
        } catch (error) {
            console.error('Error initializing schools directory:', error);
            this.showError('Failed to load schools data. Please try again later.');
        }
    }

    async loadSchoolsData() {
        try {
            const response = await fetch('data/schools_data.json');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            this.schools = data.schools || [];
            this.filteredSchools = [...this.schools];
            
            // Update total schools count in hero section
            const totalSchoolsElement = document.getElementById('total-schools');
            if (totalSchoolsElement) {
                totalSchoolsElement.textContent = data.total_schools || this.schools.length;
            }
        } catch (error) {
            console.error('Error loading schools data:', error);
            throw error;
        }
    }

    setupEventListeners() {
        // Search functionality
        const searchInput = document.getElementById('search-input');
        const searchBtn = document.getElementById('search-btn');
        
        if (searchInput && searchBtn) {
            searchInput.addEventListener('input', this.debounce(() => this.handleSearch(), 300));
            searchBtn.addEventListener('click', () => this.handleSearch());
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.handleSearch();
                }
            });
        }

        // Filter functionality
        const districtFilter = document.getElementById('district-filter');
        const categoryFilter = document.getElementById('category-filter');
        const clearFilters = document.getElementById('clear-filters');

        if (districtFilter) {
            districtFilter.addEventListener('change', () => this.applyFilters());
        }
        if (categoryFilter) {
            categoryFilter.addEventListener('change', () => this.applyFilters());
        }
        if (clearFilters) {
            clearFilters.addEventListener('click', () => this.clearAllFilters());
        }

        // Mobile menu toggle
        const mobileMenuBtn = document.getElementById('mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        
        if (mobileMenuBtn && mobileMenu) {
            mobileMenuBtn.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
            });
        }

        // Pagination
        const prevPageBtn = document.getElementById('prev-page');
        const nextPageBtn = document.getElementById('next-page');
        
        if (prevPageBtn) {
            prevPageBtn.addEventListener('click', () => this.goToPage(this.currentPage - 1));
        }
        if (nextPageBtn) {
            nextPageBtn.addEventListener('click', () => this.goToPage(this.currentPage + 1));
        }
    }

    populateFilters() {
        // Populate district filter
        const districtFilter = document.getElementById('district-filter');
        if (districtFilter) {
            const districts = [...new Set(this.schools.map(school => school.district))].sort();
            districts.forEach(district => {
                const option = document.createElement('option');
                option.value = district;
                option.textContent = district;
                districtFilter.appendChild(option);
            });
        }
    }

    updateStatistics() {
        const primaryCount = this.schools.filter(school => 
            school.category === 'Pre-Primary and Primary Level').length;
        const daySecondaryCount = this.schools.filter(school => 
            school.category === 'Day Secondary Level').length;
        const boardingSecondaryCount = this.schools.filter(school => 
            school.category === 'Boarding Secondary Schools').length;

        const primaryCountElement = document.getElementById('primary-count');
        const daySecondaryCountElement = document.getElementById('day-secondary-count');
        const boardingSecondaryCountElement = document.getElementById('boarding-secondary-count');

        if (primaryCountElement) {
            this.animateCounter(primaryCountElement, primaryCount);
        }
        if (daySecondaryCountElement) {
            this.animateCounter(daySecondaryCountElement, daySecondaryCount);
        }
        if (boardingSecondaryCountElement) {
            this.animateCounter(boardingSecondaryCountElement, boardingSecondaryCount);
        }
    }

    animateCounter(element, target) {
        let current = 0;
        const increment = target / 50;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            element.textContent = Math.floor(current);
        }, 30);
    }

    handleSearch() {
        const searchInput = document.getElementById('search-input');
        if (!searchInput) return;

        const searchTerm = searchInput.value.toLowerCase().trim();
        
        if (searchTerm === '') {
            this.filteredSchools = [...this.schools];
        } else {
            this.filteredSchools = this.schools.filter(school => 
                school.name.toLowerCase().includes(searchTerm) ||
                school.district.toLowerCase().includes(searchTerm) ||
                school.code.toLowerCase().includes(searchTerm)
            );
        }
        
        this.currentPage = 1;
        this.applyFilters();
    }

    applyFilters() {
        const districtFilter = document.getElementById('district-filter');
        const categoryFilter = document.getElementById('category-filter');
        
        let filtered = [...this.filteredSchools];

        // Apply district filter
        if (districtFilter && districtFilter.value) {
            filtered = filtered.filter(school => school.district === districtFilter.value);
        }

        // Apply category filter
        if (categoryFilter && categoryFilter.value) {
            filtered = filtered.filter(school => school.category === categoryFilter.value);
        }

        this.filteredSchools = filtered;
        this.currentPage = 1;
        this.displaySchools();
    }

    clearAllFilters() {
        const searchInput = document.getElementById('search-input');
        const districtFilter = document.getElementById('district-filter');
        const categoryFilter = document.getElementById('category-filter');

        if (searchInput) searchInput.value = '';
        if (districtFilter) districtFilter.value = '';
        if (categoryFilter) categoryFilter.value = '';

        this.filteredSchools = [...this.schools];
        this.currentPage = 1;
        this.displaySchools();
    }

    displaySchools() {
        const container = document.getElementById('schools-container');
        const resultsCount = document.getElementById('results-count');
        
        if (!container) return;

        // Update results count
        if (resultsCount) {
            resultsCount.textContent = this.filteredSchools.length;
        }

        // Calculate pagination
        const totalPages = Math.ceil(this.filteredSchools.length / this.schoolsPerPage);
        const startIndex = (this.currentPage - 1) * this.schoolsPerPage;
        const endIndex = startIndex + this.schoolsPerPage;
        const schoolsToShow = this.filteredSchools.slice(startIndex, endIndex);

        // Clear container
        container.innerHTML = '';

        if (schoolsToShow.length === 0) {
            container.innerHTML = `
                <div class="col-span-full text-center py-12">
                    <div class="text-6xl mb-4">🔍</div>
                    <h3 class="text-xl font-medium text-gray-600 mb-2">No schools found</h3>
                    <p class="text-gray-500">Try adjusting your search or filters</p>
                </div>
            `;
            this.hidePagination();
            return;
        }

        // Create grid container
        const grid = document.createElement('div');
        grid.className = 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6';

        // Create school cards
        schoolsToShow.forEach(school => {
            const card = this.createSchoolCard(school);
            grid.appendChild(card);
        });

        container.appendChild(grid);

        // Update pagination
        if (totalPages > 1) {
            this.updatePagination(totalPages);
        } else {
            this.hidePagination();
        }
    }

    createSchoolCard(school) {
        const card = document.createElement('div');
        card.className = 'school-card bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg';
        
        // Get category icon and color
        const categoryInfo = this.getCategoryInfo(school.category);
        
        card.innerHTML = `
            <div class="bg-gradient-to-r ${categoryInfo.gradient} text-white p-6">
                <div class="text-4xl mb-2">${categoryInfo.icon}</div>
                <div class="text-sm font-medium opacity-90">${school.category}</div>
            </div>
            <div class="p-6">
                <h3 class="text-lg font-bold mb-2 text-gray-800">${this.escapeHtml(school.name)}</h3>
                <div class="space-y-2 text-sm text-gray-600 mb-4">
                    <div class="flex items-center">
                        <span class="font-medium mr-2">Code:</span>
                        <span class="bg-gray-100 px-2 py-1 rounded text-xs font-mono">${school.code}</span>
                    </div>
                    <div class="flex items-center">
                        <span class="font-medium mr-2">District:</span>
                        <span>${this.escapeHtml(school.district)}</span>
                    </div>
                </div>
                <button class="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 px-4 rounded font-medium transition-colors" 
                        onclick="schoolsDirectory.showSchoolDetails('${school.code}')">
                    View Details
                </button>
            </div>
        `;
        
        return card;
    }

    getCategoryInfo(category) {
        switch (category) {
            case 'Pre-Primary and Primary Level':
                return {
                    icon: '🎒',
                    gradient: 'from-blue-500 to-blue-600'
                };
            case 'Day Secondary Level':
                return {
                    icon: '📚',
                    gradient: 'from-green-500 to-green-600'
                };
            case 'Boarding Secondary Schools':
                return {
                    icon: '🏫',
                    gradient: 'from-purple-500 to-purple-600'
                };
            default:
                return {
                    icon: '🏛️',
                    gradient: 'from-gray-500 to-gray-600'
                };
        }
    }

    showSchoolDetails(schoolCode) {
        const school = this.schools.find(s => s.code === schoolCode);
        if (!school) return;

        // Create modal
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4';
        modal.onclick = (e) => {
            if (e.target === modal) {
                document.body.removeChild(modal);
            }
        };

        const categoryInfo = this.getCategoryInfo(school.category);

        modal.innerHTML = `
            <div class="bg-white rounded-lg max-w-md w-full max-h-96 overflow-y-auto">
                <div class="bg-gradient-to-r ${categoryInfo.gradient} text-white p-6">
                    <div class="flex justify-between items-start">
                        <div>
                            <div class="text-4xl mb-2">${categoryInfo.icon}</div>
                            <h2 class="text-xl font-bold">${this.escapeHtml(school.name)}</h2>
                        </div>
                        <button onclick="document.body.removeChild(this.closest('.fixed'))" 
                                class="text-white hover:text-gray-200 text-2xl">&times;</button>
                    </div>
                </div>
                <div class="p-6">
                    <div class="space-y-4">
                        <div>
                            <label class="font-medium text-gray-700">School Code:</label>
                            <div class="bg-gray-100 px-3 py-2 rounded font-mono text-sm">${school.code}</div>
                        </div>
                        <div>
                            <label class="font-medium text-gray-700">Category:</label>
                            <div class="text-gray-600">${school.category}</div>
                        </div>
                        <div>
                            <label class="font-medium text-gray-700">District:</label>
                            <div class="text-gray-600">${this.escapeHtml(school.district)}</div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
    }

    updatePagination(totalPages) {
        const pagination = document.getElementById('pagination');
        const prevPageBtn = document.getElementById('prev-page');
        const nextPageBtn = document.getElementById('next-page');
        const pageNumbers = document.getElementById('page-numbers');

        if (!pagination || !pageNumbers) return;

        pagination.classList.remove('hidden');

        // Update prev/next buttons
        if (prevPageBtn) {
            prevPageBtn.disabled = this.currentPage === 1;
        }
        if (nextPageBtn) {
            nextPageBtn.disabled = this.currentPage === totalPages;
        }

        // Update page numbers
        pageNumbers.innerHTML = '';
        
        const maxVisiblePages = 5;
        let startPage = Math.max(1, this.currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
        
        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }

        for (let i = startPage; i <= endPage; i++) {
            const pageBtn = document.createElement('button');
            pageBtn.textContent = i;
            pageBtn.className = `px-3 py-2 rounded ${
                i === this.currentPage 
                    ? 'bg-indigo-600 text-white' 
                    : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
            }`;
            pageBtn.onclick = () => this.goToPage(i);
            pageNumbers.appendChild(pageBtn);
        }
    }

    hidePagination() {
        const pagination = document.getElementById('pagination');
        if (pagination) {
            pagination.classList.add('hidden');
        }
    }

    goToPage(page) {
        const totalPages = Math.ceil(this.filteredSchools.length / this.schoolsPerPage);
        if (page < 1 || page > totalPages) return;
        
        this.currentPage = page;
        this.displaySchools();
        
        // Scroll to top of schools section
        const schoolsSection = document.getElementById('schools');
        if (schoolsSection) {
            schoolsSection.scrollIntoView({ behavior: 'smooth' });
        }
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    showError(message) {
        const container = document.getElementById('schools-container');
        if (container) {
            container.innerHTML = `
                <div class="col-span-full text-center py-12">
                    <div class="text-6xl mb-4">⚠️</div>
                    <h3 class="text-xl font-medium text-red-600 mb-2">Error</h3>
                    <p class="text-gray-600">${message}</p>
                </div>
            `;
        }
    }
}

// Initialize the schools directory when the page loads
let schoolsDirectory;
document.addEventListener('DOMContentLoaded', () => {
    schoolsDirectory = new SchoolsDirectory();
});

// Smooth scrolling for navigation links
document.addEventListener('DOMContentLoaded', () => {
    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});

