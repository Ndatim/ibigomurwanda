# Rwanda Schools Directory

A comprehensive static website displaying all schools in Rwanda, sourced from the Ministry of Education (MINEDUC) official schools directory.

## Features

- **Complete School Database**: 588 schools across Rwanda
- **Advanced Search**: Search by school name, district, or school code
- **Smart Filtering**: Filter by district and school category
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Interactive Statistics**: Real-time statistics display
- **Detailed School Information**: View complete school details in modal windows
- **Pagination**: Efficient browsing with pagination support

## School Categories

1. **Pre-Primary and Primary Level Schools**
2. **Day Secondary Level Schools**
3. **Boarding Secondary Schools**

## Data Source

All school data is sourced from the official Ministry of Education (MINEDUC) schools directory of the Republic of Rwanda.

## Technical Details

### Technologies Used
- HTML5
- CSS3 (with Tailwind CSS)
- Vanilla JavaScript (ES6+)
- JSON for data storage

### File Structure
```
rwanda-schools-website/
├── index.html              # Main HTML file
├── css/
│   └── styles.css          # Additional custom styles
├── js/
│   └── app.js              # Main JavaScript application
├── data/
│   └── schools_data.json   # School database
└── README.md               # This file
```

### Features Implementation

#### Search Functionality
- Real-time search with debouncing
- Searches across school name, district, and school code
- Case-insensitive matching

#### Filtering System
- District-based filtering
- Category-based filtering
- Combined filter support
- Clear filters functionality

#### Pagination
- 12 schools per page
- Smart pagination with page numbers
- Previous/Next navigation
- Responsive pagination controls

#### Responsive Design
- Mobile-first approach
- Responsive grid layout
- Mobile menu for navigation
- Touch-friendly interface

#### Accessibility
- Keyboard navigation support
- Screen reader friendly
- High contrast mode support
- Reduced motion support for users with vestibular disorders

### Browser Support
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Installation and Usage

1. Extract the zip file to your web server directory
2. Open `index.html` in a web browser
3. For local development, serve the files using a local web server:
   ```bash
   # Using Python 3
   python -m http.server 8000
   
   # Using Node.js (with http-server)
   npx http-server
   ```

## Data Structure

Each school entry contains:
- `code`: Unique school identification code
- `name`: Official school name
- `category`: School category (Primary, Day Secondary, or Boarding Secondary)
- `district`: District where the school is located

## Performance Optimizations

- Lazy loading of external resources
- Debounced search to reduce API calls
- Efficient DOM manipulation
- Optimized CSS with critical path rendering
- Compressed and minified assets

## Future Enhancements

- School location mapping
- Advanced search filters (by establishment year, school type, etc.)
- Export functionality (PDF, Excel)
- Print-friendly layouts
- Offline support with Service Workers
- Multi-language support (Kinyarwanda, French)

## License

This project contains public data from the Ministry of Education of Rwanda. The website implementation is provided as-is for educational and informational purposes.

## Contact

For questions about the data, please contact the Ministry of Education (MINEDUC) of Rwanda.

---

**Last Updated**: January 2025  
**Total Schools**: 588  
**Data Source**: MINEDUC Rwanda Schools Directory

